'''
Handles the user interface for the Rock Paper Scissors game.
'''
import tkinter as tk
from tkinter import messagebox
from game_logic import get_computer_choice, determine_winner
class RockPaperScissorsApp:
    def __init__(self, master):
        self.master = master
        master.title("Rock Paper Scissors Game")
        self.label = tk.Label(master, text="Choose Rock, Paper, or Scissors:")
        self.label.pack()
        self.rock_button = tk.Button(master, text="Rock", command=lambda: self.play_game('rock'))
        self.rock_button.pack()
        self.paper_button = tk.Button(master, text="Paper", command=lambda: self.play_game('paper'))
        self.paper_button.pack()
        self.scissors_button = tk.Button(master, text="Scissors", command=lambda: self.play_game('scissors'))
        self.scissors_button.pack()
        self.result_label = tk.Label(master, text="")
        self.result_label.pack()
    def play_game(self, user_choice):
        computer_choice = get_computer_choice()
        result = determine_winner(user_choice, computer_choice)
        self.update_result(user_choice, computer_choice, result)
    def update_result(self, user_choice, computer_choice, result):
        messagebox.showinfo("Game Result", f"You chose: {user_choice}\nComputer chose: {computer_choice}\nResult: {result}")