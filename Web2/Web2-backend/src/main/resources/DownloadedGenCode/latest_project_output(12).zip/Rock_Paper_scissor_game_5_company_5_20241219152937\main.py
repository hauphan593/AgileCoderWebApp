'''
Main file to run the Rock Paper Scissors game application.
'''
import tkinter as tk
from game_logic import get_computer_choice, determine_winner
class RockPaperScissorsApp:
    def __init__(self, master):
        self.master = master
        master.title("Rock Paper Scissors Game")
        self.user_choice = None
        self.computer_choice = None
        self.result_label = tk.Label(master, text="Choose Rock, Paper, or Scissors", font=("Arial", 16))
        self.result_label.pack()
        self.rock_button = tk.Button(master, text="Rock", command=lambda: self.get_user_choice("rock"))
        self.rock_button.pack(side=tk.LEFT)
        self.paper_button = tk.Button(master, text="Paper", command=lambda: self.get_user_choice("paper"))
        self.paper_button.pack(side=tk.LEFT)
        self.scissors_button = tk.Button(master, text="Scissors", command=lambda: self.get_user_choice("scissors"))
        self.scissors_button.pack(side=tk.LEFT)
        self.result_display = tk.Label(master, text="", font=("Arial", 14))
        self.result_display.pack()
    def get_user_choice(self, choice):
        self.user_choice = choice
        self.computer_choice = get_computer_choice()
        self.update_result()
    def update_result(self):
        winner = determine_winner(self.user_choice, self.computer_choice)
        result_text = f"You chose: {self.user_choice}\nComputer chose: {self.computer_choice}\nWinner: {winner}"
        self.result_display.config(text=result_text)
if __name__ == "__main__":
    root = tk.Tk()
    app = RockPaperScissorsApp(root)
    root.mainloop()