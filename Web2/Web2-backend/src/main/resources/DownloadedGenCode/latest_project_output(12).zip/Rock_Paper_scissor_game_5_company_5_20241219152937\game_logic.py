'''
Contains the game logic for the Rock Paper Scissors game.
'''
import random
def get_computer_choice():
    """Generates the computer's choice: rock, paper, or scissors.
    Returns:
        str: The computer's choice.
    """
    return random.choice(["rock", "paper", "scissors"])
def determine_winner(user_choice, computer_choice):
    """Determines the winner based on user and computer choices.
    Args:
        user_choice (str): The user's choice (rock, paper, or scissors).
        computer_choice (str): The computer's choice (rock, paper, or scissors).
    Returns:
        str: The result of the game indicating the winner.
    """
    if user_choice == computer_choice:
        return "It's a tie!"
    elif (user_choice == "rock" and computer_choice == "scissors") or \
         (user_choice == "scissors" and computer_choice == "paper") or \
         (user_choice == "paper" and computer_choice == "rock"):
        return "You win!"
    else:
        return "Computer wins!"