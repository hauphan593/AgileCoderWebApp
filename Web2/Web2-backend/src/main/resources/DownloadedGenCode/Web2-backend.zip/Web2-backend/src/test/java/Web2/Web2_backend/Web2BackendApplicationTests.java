package Web2.Web2_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Web2BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
