'''
This module contains the GUI components for the Rock Paper Scissors game.
It provides a simple interface for the user to play the game and displays the computer's choice.
'''
import tkinter as tk
from tkinter import messagebox
from game_logic import GameLogic
class GameUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Rock Paper Scissors Game")
        self.game_logic = GameLogic()
        self.label = tk.Label(master, text="Choose Rock, Paper, or Scissors:")
        self.label.pack()
        self.rock_button = tk.Button(master, text="Rock", command=lambda: self.play_game('rock'))
        self.rock_button.pack()
        self.paper_button = tk.Button(master, text="Paper", command=lambda: self.play_game('paper'))
        self.paper_button.pack()
        self.scissors_button = tk.Button(master, text="Scissors", command=lambda: self.play_game('scissors'))
        self.scissors_button.pack()
        self.result_label = tk.Label(master, text="")
        self.result_label.pack()
        self.computer_choice_label = tk.Label(master, text="")
        self.computer_choice_label.pack()
        self.score_label = tk.Label(master, text="Score - You: 0 | Computer: 0")
        self.score_label.pack()
        self.reset_button = tk.Button(master, text="Reset", command=self.reset_game)
        self.reset_button.pack()
        self.help_button = tk.Button(master, text="Help", command=self.show_help)
        self.help_button.pack()
    def play_game(self, user_choice):
        if user_choice not in self.game_logic.choices:
            messagebox.showerror("Invalid choice", "Please choose Rock, Paper, or Scissors.")
            return
        computer_choice = self.game_logic.get_computer_choice()
        result = self.game_logic.determine_winner(user_choice, computer_choice)
        self.update_result(f"You chose {user_choice}, Computer chose {computer_choice}. {result}")
        self.display_computer_choice(computer_choice)
        self.update_score()
    def update_result(self, result):
        self.result_label.config(text=result)
    def display_computer_choice(self, computer_choice):
        self.computer_choice_label.config(text=f"Computer chose: {computer_choice}")
    def update_score(self):
        user_score, computer_score = self.game_logic.get_scores()
        self.score_label.config(text=f"Score - You: {user_score} | Computer: {computer_score}")
    def reset_game(self):
        self.game_logic.reset_scores()
        self.score_label.config(text="Score - You: 0 | Computer: 0")
        self.result_label.config(text="")
        self.computer_choice_label.config(text="")
    def show_help(self):
        help_message = "Instructions:\nChoose Rock, Paper, or Scissors.\nRock beats Scissors, Scissors beats Paper, Paper beats Rock.\nFirst to 5 wins!"
        messagebox.showinfo("Help", help_message)