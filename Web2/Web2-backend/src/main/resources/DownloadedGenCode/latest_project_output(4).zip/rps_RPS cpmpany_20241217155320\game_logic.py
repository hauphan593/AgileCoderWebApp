'''
This module contains the game logic for the Rock Paper Scissors game.
It includes functions to get the computer's choice, determine the winner, and manage scores.
'''
import random
class GameLogic:
    def __init__(self):
        self.choices = ['rock', 'paper', 'scissors']
        self.user_score = 0
        self.computer_score = 0
    def get_computer_choice(self):
        return random.choice(self.choices)
    def determine_winner(self, user_choice, computer_choice):
        if user_choice == computer_choice:
            return "It's a tie!"
        elif (user_choice == 'rock' and computer_choice == 'scissors') or \
             (user_choice == 'paper' and computer_choice == 'rock') or \
             (user_choice == 'scissors' and computer_choice == 'paper'):
            self.user_score += 1
            return "You win!"
        else:
            self.computer_score += 1
            return "Computer wins!"
    def get_scores(self):
        return self.user_score, self.computer_score
    def reset_scores(self):
        self.user_score = 0
        self.computer_score = 0