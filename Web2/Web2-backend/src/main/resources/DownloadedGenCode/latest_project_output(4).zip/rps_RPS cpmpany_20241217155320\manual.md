```markdown
# Rock Paper Scissors Game

Welcome to the Rock Paper Scissors Game! This application allows you to play the classic game against a computer opponent. Below, you will find a detailed user manual that includes an introduction to the main functions of the software, installation instructions, and how to play the game.

## Main Functions

The Rock Paper Scissors Game consists of the following main components:

1. **Game Logic**: The core logic of the game is handled by the `GameLogic` class, which includes functions to:
   - Get the computer's choice.
   - Determine the winner based on user and computer choices.
   - Manage and display scores.
   - Reset scores for a new game.

2. **User Interface**: The graphical user interface (GUI) is built using Tkinter and allows users to:
   - Choose between Rock, Paper, or Scissors.
   - View the computer's choice and the result of each round.
   - See the current score.
   - Reset the game and view help instructions.

3. **Unit Testing**: The application includes unit tests to ensure the game logic functions correctly, verifying the winner determination and score management.

## Installation Instructions

To run the Rock Paper Scissors Game, you need to have Python installed on your machine. Follow these steps to set up the environment:

1. **Install Python**: Download and install Python from the official website: [python.org](https://www.python.org/downloads/).

2. **Install Tkinter**: Tkinter is included with Python installations on Windows and macOS. For Linux, you may need to install it separately. Use the following command:
   ```bash
   sudo apt-get install python3-tk
   ```

3. **Install Required Dependencies**: Open your terminal or command prompt and run the following command to install any additional dependencies:
   ```bash
   pip install -r requirements.txt
   ```
   (Note: If there is no `requirements.txt` file, the game should work with just Python and Tkinter.)

## How to Use/Play the Game

1. **Run the Application**: Navigate to the directory containing the game files and run the following command:
   ```bash
   python main.py
   ```

2. **Choose Your Move**: Once the GUI opens, you will see buttons for "Rock", "Paper", and "Scissors". Click on one of these buttons to make your choice.

3. **View Results**: After making your choice, the computer will randomly select its move. The result of the round will be displayed, indicating whether you won, lost, or tied.

4. **Check Scores**: The current score will be displayed on the screen, showing your score and the computer's score.

5. **Reset the Game**: If you want to start a new game, click the "Reset" button to clear the scores.

6. **Help Instructions**: If you need assistance, click the "Help" button to view the game instructions.

## Enjoy the Game!

Have fun playing the Rock Paper Scissors Game! Challenge yourself against the computer and see if you can achieve a winning streak. If you encounter any issues or have questions, feel free to reach out for support.
```