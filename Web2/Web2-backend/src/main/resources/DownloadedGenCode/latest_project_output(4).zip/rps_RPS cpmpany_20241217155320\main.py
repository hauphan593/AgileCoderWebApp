'''
This module contains the main entry point for the Rock Paper Scissors game and unit tests for the game logic functions.
'''
import unittest
from game_logic import GameLogic
from game_ui import GameUI
import tkinter as tk
class TestGameLogic(unittest.TestCase):
    def setUp(self):
        self.game_logic = GameLogic()
    def test_determine_winner(self):
        self.assertEqual(self.game_logic.determine_winner('rock', 'scissors'), "You win!")
        self.assertEqual(self.game_logic.determine_winner('paper', 'rock'), "You win!")
        self.assertEqual(self.game_logic.determine_winner('scissors', 'paper'), "You win!")
        self.assertEqual(self.game_logic.determine_winner('rock', 'paper'), "Computer wins!")
        self.assertEqual(self.game_logic.determine_winner('paper', 'scissors'), "Computer wins!")
        self.assertEqual(self.game_logic.determine_winner('scissors', 'rock'), "Computer wins!")
        self.assertEqual(self.game_logic.determine_winner('rock', 'rock'), "It's a tie!")
    def test_get_scores(self):
        self.game_logic.user_score = 3
        self.game_logic.computer_score = 2
        self.assertEqual(self.game_logic.get_scores(), (3, 2))
    def test_reset_scores(self):
        self.game_logic.user_score = 3
        self.game_logic.computer_score = 2
        self.game_logic.reset_scores()
        self.assertEqual(self.game_logic.get_scores(), (0, 0))
if __name__ == '__main__':
    root = tk.Tk()
    game_ui = GameUI(root)
    root.mainloop()
    unittest.main()