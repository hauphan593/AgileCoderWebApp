'''
Contains the Game class that handles the game logic for Rock Paper Scissors.
'''
import random
class Game:
    def __init__(self):
        self.choices = ['Rock', 'Paper', 'Scissors']
        self.score = {'wins': 0, 'losses': 0, 'ties': 0}
    def play_round(self, user_choice):
        if user_choice not in self.choices:
            return "Invalid choice! Please choose Rock, Paper, or Scissors.", None
        computer_choice = random.choice(self.choices)
        if user_choice == computer_choice:
            self.score['ties'] += 1
            return "It's a tie!", computer_choice
        elif (user_choice == 'Rock' and computer_choice == 'Scissors') or \
             (user_choice == 'Paper' and computer_choice == 'Rock') or \
             (user_choice == 'Scissors' and computer_choice == 'Paper'):
            self.score['wins'] += 1
            return "You win!", computer_choice
        else:
            self.score['losses'] += 1
            return "You lose!", computer_choice
    def reset_scores(self):
        self.score = {'wins': 0, 'losses': 0, 'ties': 0}