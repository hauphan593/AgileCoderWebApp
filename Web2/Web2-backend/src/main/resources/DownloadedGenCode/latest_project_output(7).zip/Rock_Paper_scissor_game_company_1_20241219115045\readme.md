# Rock Paper Scissors Game
## Overview
This is a simple Rock Paper Scissors game implemented in Python using Tkinter for the GUI. The game allows users to play against the computer and keeps track of wins, losses, and ties.
## Installation Instructions
1. Ensure you have Python installed on your machine.
2. Clone the repository or download the source code.
3. Navigate to the project directory.
4. Run the game using the command: