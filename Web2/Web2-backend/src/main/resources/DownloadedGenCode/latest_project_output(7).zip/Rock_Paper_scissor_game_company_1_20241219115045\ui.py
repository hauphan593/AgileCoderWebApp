'''
Contains the UI class that manages the graphical user interface for the game.
'''
import tkinter as tk
from tkinter import messagebox
class UI:
    def __init__(self, game):
        self.game = game
        self.window = tk.Tk()
        self.window.title("Rock Paper Scissors")
        self.label = tk.Label(self.window, text="Choose Rock, Paper, or Scissors:")
        self.label.pack()
        self.button_rock = tk.Button(self.window, text="Rock", command=lambda: self.play('Rock'))
        self.button_rock.pack()
        self.button_paper = tk.Button(self.window, text="Paper", command=lambda: self.play('Paper'))
        self.button_paper.pack()
        self.button_scissors = tk.Button(self.window, text="Scissors", command=lambda: self.play('Scissors'))
        self.button_scissors.pack()
        self.score_label = tk.Label(self.window, text=self.get_score_text())
        self.score_label.pack()
        self.reset_button = tk.Button(self.window, text="Reset Game", command=self.reset_game)
        self.reset_button.pack()
        self.exit_button = tk.Button(self.window, text="Exit", command=self.exit_game)
        self.exit_button.pack()
    def play(self, user_choice):
        result, computer_choice = self.game.play_round(user_choice)
        if computer_choice is None:  # This means the input was invalid
            messagebox.showerror("Error", result)  # Show error message
        else:
            self.show_result(result, computer_choice)
            self.update_score()
    def update_score(self):
        self.score_label.config(text=self.get_score_text())
    def get_score_text(self):
        score = self.game.score
        return f"Wins: {score['wins']} | Losses: {score['losses']} | Ties: {score['ties']}"
    def show_result(self, result, computer_choice):
        messagebox.showinfo("Result", f"{result}\nComputer chose: {computer_choice}")
    def reset_game(self):
        self.game.reset_scores()
        self.update_score()
    def exit_game(self):
        self.window.destroy()
    def run(self):
        self.window.mainloop()