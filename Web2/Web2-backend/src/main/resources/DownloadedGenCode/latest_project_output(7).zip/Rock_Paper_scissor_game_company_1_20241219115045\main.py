'''
Contains unit tests for the Game class.
'''
import unittest
from game import Game
class TestGame(unittest.TestCase):
    def setUp(self):
        self.game = Game()
    def test_play_round_wins(self):
        self.assertEqual(self.game.play_round('Rock')[0], "You win!")
        self.assertEqual(self.game.play_round('Paper')[0], "You win!")
        self.assertEqual(self.game.play_round('Scissors')[0], "You win!")
    def test_play_round_losses(self):
        self.assertEqual(self.game.play_round('Rock')[0], "You lose!")
        self.assertEqual(self.game.play_round('Paper')[0], "You lose!")
        self.assertEqual(self.game.play_round('Scissors')[0], "You lose!")
    def test_play_round_ties(self):
        self.assertEqual(self.game.play_round('Rock')[0], "It's a tie!")
        self.assertEqual(self.game.play_round('Paper')[0], "It's a tie!")
        self.assertEqual(self.game.play_round('Scissors')[0], "It's a tie!")
    def test_reset_scores(self):
        self.game.play_round('Rock')
        self.game.reset_scores()
        self.assertEqual(self.game.score, {'wins': 0, 'losses': 0, 'ties': 0})
if __name__ == '__main__':
    unittest.main()