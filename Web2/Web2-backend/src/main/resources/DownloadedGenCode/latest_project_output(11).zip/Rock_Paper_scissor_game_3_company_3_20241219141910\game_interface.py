'''
Contains the graphical user interface for the Rock Paper Scissors game.
'''
import tkinter as tk
from game_logic import GameLogic
class GameInterface:
    def __init__(self):
        self.game_logic = GameLogic()
        self.window = tk.Tk()
        self.window.title("Rock Paper Scissors Game")
        self.create_widgets()
    def create_widgets(self):
        self.label = tk.Label(self.window, text="Choose Rock, Paper, or Scissors:")
        self.label.pack()
        self.play_button_rock = tk.Button(self.window, text="Rock", command=lambda: self.play_game("Rock"))
        self.play_button_rock.pack()
        self.play_button_paper = tk.Button(self.window, text="Paper", command=lambda: self.play_game("Paper"))
        self.play_button_paper.pack()
        self.play_button_scissors = tk.Button(self.window, text="Scissors", command=lambda: self.play_game("Scissors"))
        self.play_button_scissors.pack()
        self.reset_button = tk.Button(self.window, text="Reset", command=self.reset_game)
        self.reset_button.pack()
        self.result_label = tk.Label(self.window, text="")
        self.result_label.pack()
        self.invalid_input_label = tk.Label(self.window, text="", fg="red")
        self.invalid_input_label.pack()
        self.score_label = tk.Label(self.window, text="")
        self.score_label.pack()
    def play_game(self, user_choice):
        result = self.game_logic.play(user_choice)
        self.result_label.config(text=result)
        self.score_label.config(text=self.game_logic.get_score_summary())
        self.invalid_input_label.config(text="")  # Clear invalid input message
    def reset_game(self):
        reset_message = self.game_logic.reset_scores()
        self.result_label.config(text=reset_message)
        self.score_label.config(text=self.game_logic.get_score_summary())
        self.invalid_input_label.config(text="")  # Clear invalid input message
    def show_invalid_input_message(self):
        self.invalid_input_label.config(text="Invalid input! Please choose Rock, Paper, or Scissors.")
    def run(self):
        self.window.mainloop()