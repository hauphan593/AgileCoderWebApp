'''
Main entry point for the Rock Paper Scissors game with GUI.
'''
from gui import GameGUI
if __name__ == "__main__":
    app = GameGUI()
    app.run()