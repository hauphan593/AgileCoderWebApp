'''
Game logic for the Rock Paper Scissors game.
'''
import random
class Game:
    def __init__(self):
        self.choices = ['rock', 'paper', 'scissors']
        self.user_score = 0
        self.rounds_played = 0
    def play(self, user_choice):
        '''
        Play a round of Rock Paper Scissors with the user's choice.
        '''
        user_choice = user_choice.strip().lower()  # Improve input validation
        if not self.validate_input(user_choice):
            return "Invalid choice! Please select rock, paper, or scissors."
        computer_choice = random.choice(self.choices)
        winner = self.determine_winner(user_choice, computer_choice)
        self.rounds_played += 1
        if winner == "You win!":
            self.user_score += 1
        return f"You chose {user_choice}, computer chose {computer_choice}. {winner} Score: {self.user_score}, Rounds: {self.rounds_played}"
    def validate_input(self, user_choice):
        '''
        Validate the user's input to ensure it is a valid choice.
        '''
        return user_choice in self.choices
    def determine_winner(self, user_choice, computer_choice):
        '''
        Determine the winner of the game based on user and computer choices.
        '''
        if user_choice == computer_choice:
            return "It's a tie!"
        elif (user_choice == 'rock' and computer_choice == 'scissors') or \
             (user_choice == 'paper' and computer_choice == 'rock') or \
             (user_choice == 'scissors' and computer_choice == 'paper'):
            return "You win!"
        else:
            return "You lose!"
    def reset(self):
        '''
        Reset the game scores and rounds played.
        '''
        self.user_score = 0
        self.rounds_played = 0