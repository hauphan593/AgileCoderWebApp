'''
Graphical User Interface for the Rock Paper Scissors game using Tkinter.
'''
import tkinter as tk
from tkinter import messagebox
from game import Game
class GameGUI:
    def __init__(self):
        self.game = Game()
        self.window = tk.Tk()
        self.window.title("Rock Paper Scissors Game")
        self.label = tk.Label(self.window, text="Choose: ")
        self.label.pack()
        self.choice_var = tk.StringVar(value="rock")
        self.choices = ["rock", "paper", "scissors"]
        self.dropdown = tk.OptionMenu(self.window, self.choice_var, *self.choices)
        self.dropdown.pack()
        self.play_button = tk.Button(self.window, text="Play", command=self.play_game)
        self.play_button.pack()
        self.reset_button = tk.Button(self.window, text="Reset", command=self.reset_game)
        self.reset_button.pack()
        self.result_label = tk.Label(self.window, text="")
        self.result_label.pack()
    def play_game(self):
        user_choice = self.choice_var.get()
        result = self.game.play(user_choice)
        self.update_result(result)
    def reset_game(self):
        self.game.reset()
        self.result_label.config(text="Game reset! Score: 0, Rounds: 0")
    def update_result(self, result):
        self.result_label.config(text=result)
    def run(self):
        self.window.mainloop()