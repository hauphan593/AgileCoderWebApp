'''
Contains test cases for the GameLogic class.
'''
import unittest
from game_logic import GameLogic
class TestGameLogic(unittest.TestCase):
    def setUp(self):
        self.game_logic = GameLogic()
    def test_normalize_input(self):
        self.assertEqual(self.game_logic.normalize_input("rock"), "Rock")
        self.assertEqual(self.game_logic.normalize_input("PAPER"), "Paper")
        self.assertEqual(self.game_logic.normalize_input("Scissors"), "Scissors")
        self.assertIsNone(self.game_logic.normalize_input("invalid"))
    def test_play_valid_choices(self):
        self.assertIn("You chose", self.game_logic.play("Rock"))
        self.assertIn("You chose", self.game_logic.play("Paper"))
        self.assertIn("You chose", self.game_logic.play("Scissors"))
    def test_play_invalid_choice(self):
        self.assertEqual(self.game_logic.play("invalid"), "Invalid choice! Please choose Rock, Paper, or Scissors.")
    def test_reset_scores(self):
        self.game_logic.user_score = 1
        self.game_logic.computer_score = 2
        self.game_logic.reset_scores()
        self.assertEqual(self.game_logic.user_score, 0)
        self.assertEqual(self.game_logic.computer_score, 0)
if __name__ == '__main__':
    unittest.main()