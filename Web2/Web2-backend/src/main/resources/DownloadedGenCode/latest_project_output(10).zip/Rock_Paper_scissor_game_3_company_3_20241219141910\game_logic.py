'''
Contains the logic for the Rock Paper Scissors game.
'''
import random
class GameLogic:
    def __init__(self):
        self.choices = ["Rock", "Paper", "Scissors"]
        self.user_score = 0
        self.computer_score = 0
        self.rounds_played = 0
    def normalize_input(self, user_choice):
        '''
        Normalize user input to handle variations and invalid characters.
        '''
        normalized_choice = ''.join(filter(str.isalpha, user_choice.strip())).capitalize()
        if normalized_choice in self.choices:
            return normalized_choice
        return None
    def play(self, user_choice):
        '''
        Play a round of Rock Paper Scissors against the computer.
        Validates user input and determines the outcome of the game.
        '''
        user_choice = self.normalize_input(user_choice)
        if user_choice is None:
            return "Invalid choice! Please choose Rock, Paper, or Scissors."
        computer_choice = random.choice(self.choices)
        self.rounds_played += 1
        if user_choice == computer_choice:
            return f"Both chose {user_choice}. It's a tie! Score: {self.user_score} - {self.computer_score} (Rounds played: {self.rounds_played})"
        elif (user_choice == "Rock" and computer_choice == "Scissors") or \
             (user_choice == "Paper" and computer_choice == "Rock") or \
             (user_choice == "Scissors" and computer_choice == "Paper"):
            self.user_score += 1
            return f"You chose {user_choice}. Computer chose {computer_choice}. You win! Score: {self.user_score} - {self.computer_score} (Rounds played: {self.rounds_played})"
        else:
            self.computer_score += 1
            return f"You chose {user_choice}. Computer chose {computer_choice}. You lose! Score: {self.user_score} - {self.computer_score} (Rounds played: {self.rounds_played})"
    def reset_scores(self):
        '''
        Reset the scores and rounds played.
        '''
        self.user_score = 0
        self.computer_score = 0
        self.rounds_played = 0
        return "Scores have been reset!"
    def get_score_summary(self):
        '''
        Get a summary of the current scores.
        '''
        return f"Score: {self.user_score} - {self.computer_score} (Rounds played: {self.rounds_played})"